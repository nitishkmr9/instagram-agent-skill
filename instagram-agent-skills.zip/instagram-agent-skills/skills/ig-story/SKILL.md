---
name: ig-story
description: Create an Instagram Story sequence with stickers, polls and a clear flow. Use for story ideas, launch sequences, Q&A, behind-the-scenes or engagement stories.
---

# /ig-story

## Inputs
Goal (engage, warm up, promote, share BTS), number of frames (default 4-6), `data/account.md`.

## Steps
1. Frame 1: pattern interrupt or question, so people tap forward.
2. Middle frames: one beat per frame, max 12 words on screen.
3. Add one interactive sticker where it fits (poll, quiz, question box, slider, link). Never stack more than one per frame.
4. Final frame: single next step (reply, DM keyword, visit post).
5. For each frame specify: visual, text, sticker, and duration.

## Rules
Stories are casual: raw and conversational beats polished. Do not schedule more than 7 frames without a reason.
