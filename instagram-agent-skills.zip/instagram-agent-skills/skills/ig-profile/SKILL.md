---
name: ig-profile
description: Score an Instagram profile (bio, name field, highlights, grid, link) and rewrite the weak parts. Use when the user shares their profile, asks for a bio, wants an account review, or is starting a new account.
---

# /ig-profile

Also the **setup skill**: creates `data/account.md` if it does not exist.

## Inputs
Handle, current bio, link, niche, target audience, goal. Screenshots work.

## Steps
1. If `data/account.md` is missing, ask for: niche, audience, offer or goal, voice (3 adjectives), topics to avoid, posting capacity per week. Save the answers using `data/account.template.md`.
2. Score each element 0-10 with one line of reasoning: name field (searchable keyword), bio clarity (who, what, for whom), proof, CTA and link, highlights, grid consistency, profile photo.
3. Total score out of 70.
4. Rewrite only the elements scoring under 7. Give 3 bio options (max 150 characters), a name-field keyword suggestion, and 4-6 highlight names.
5. List the 3 highest-impact fixes in order.

## Rules
Score honestly. Do not inflate. Base grid comments only on what you can see.
