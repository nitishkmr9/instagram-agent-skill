---
name: ig-publish
description: Publish or schedule an approved Instagram post, Reel, carousel or story after explicit confirmation. Use when the user says post, publish, schedule, or 'go live'.
---

# /ig-publish

**Nothing goes live until the user says yes.**

## Steps
1. Gather: content type, media files, caption, account, date and time (with timezone).
2. Show a **confirmation card**: exact content, caption preview, account, and publish time. Ask: "Publish this now / schedule / cancel?"
3. Wait for an explicit yes. Silence, "looks good" about something else, or ambiguity is not a yes.
4. Publish through whichever Instagram publishing connector is available in this session (an Instagram Graph API connector, a scheduling-tool MCP such as PostZen, or similar). Use only tools the user has connected.
5. If no connector exists, produce a **manual posting package**: final caption in a copy-ready block, file checklist, alt text, recommended time, and step-by-step app instructions.
6. After publishing, report the post link or scheduled ID and log it in `data/publish-log.md`.

## Rules
Never publish to an account other than the one confirmed. Never edit content after confirmation without reconfirming. Check media specs first (Reels 9:16, carousel up to 20 images, caption limit 2,200 characters, 30 hashtags max).
