---
name: ig-audit
description: Audit an Instagram account's last 30 days: what worked, what failed, and what to change. Use when the user asks for an account review, growth diagnosis, or shares analytics exports.
---

# /ig-audit

## Inputs
Analytics export, screenshots, or connector data for the last 30 days. Without data, run a qualitative audit from the visible grid and say so.

## Steps
1. Summarize: posts, reach, saves, shares, comments, follows from posts.
2. Rank posts by saves + shares per reach (stronger than likes).
3. Find patterns across the top 20% and bottom 20%: format, hook type, topic, length, posting time.
4. Diagnose the single biggest constraint: reach, retention, or conversion.
5. Produce 3 actions to start, 2 to stop, 1 experiment to run next week with a clear success measure.

## Rules
Separate observed facts from inferences. Small samples (under 10 posts) get a caution note.
