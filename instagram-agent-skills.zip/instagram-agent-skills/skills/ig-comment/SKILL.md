---
name: ig-comment
description: Draft thoughtful comments for other creators' posts to grow reach and relationships. Use when the user wants engagement help, outreach comments or to work through their engagement list.
---

# /ig-comment

## Inputs
Post description or screenshot, relationship type (reach, peer, buyer), `data/account.md`.

## Steps
1. Read the post. Identify its specific point.
2. Write 3 comment options of 1-3 sentences: one adds a related insight, one asks a specific question, one shares a short relevant experience.
3. Each must reference something concrete from the post. No generic praise ("Great post!").
4. Keep the tone of a peer. No pitching, no links, no self-promotion.

## Rules
Never post comments automatically. The user copies and posts them, or confirms each one if a connector exists. Avoid repetitive comments across posts, because that triggers spam filters.
