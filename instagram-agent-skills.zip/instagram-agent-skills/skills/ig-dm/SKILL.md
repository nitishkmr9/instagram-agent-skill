---
name: ig-dm
description: Set up comment-to-DM automations and write DM reply flows. Use when the user wants keyword-triggered DMs, lead magnets via DM, or DM scripts.
---

# /ig-dm

## Inputs
Post or Reel, trigger keyword (for example CLAUDE), what is being delivered (link, file, guide), `data/account.md`.

## Steps
1. Choose a simple keyword, 4-8 letters, uncommon enough to avoid accidental triggers. Add accepted variants (case, "pls", typos).
2. Write the CTA line for the Reel or caption: "Comment KEYWORD and I'll DM you the guide."
3. Write the DM flow:
   - Message 1: friendly delivery of the resource, with the link.
   - Message 2 (optional): one question that starts a real conversation.
4. Write a public auto-reply variation set (3 options) so replies do not look identical.
5. Provide a test checklist: trigger works, link works, opt-out line present, no duplicate sends.

## Rules
Use only Instagram's official messaging API or a tool built on it. Include an easy way to stop messages. Never DM people who did not interact. Do not collect sensitive personal data.
