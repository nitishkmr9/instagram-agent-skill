---
name: ig-caption
description: Write Instagram captions with a strong first line that survives the '... more' cut, plus hashtags and CTA. Use for any caption request, rewrite, or when a Reel, carousel or story needs post copy.
---

# /ig-caption

## Inputs
The post (script, slides or description), goal, and `data/account.md` voice notes.

## Steps
1. Write the **preview line**: the text visible before "... more" (about 125 characters, front-load the keyword and the hook). Show a preview mock so the user sees exactly what is visible.
2. Write the body: short paragraphs, one idea each, line breaks for scanning. Length by goal: reach (short), trust (medium), conversion (medium with clear step).
3. End with one CTA only (save, share, comment keyword, link in bio).
4. Add 3-5 relevant hashtags and 1 keyword phrase for Instagram search. No hashtag walls.
5. Offer 2 alternate preview lines for A/B choice.

## Rules
Follow `shared/style-rules.md`. Keep the user's voice. No fake urgency, no engagement bait like "like if you agree".
