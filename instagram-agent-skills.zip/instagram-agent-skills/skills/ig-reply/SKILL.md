---
name: ig-reply
description: Draft replies to comments on the user's own posts, in their voice, and flag spam, questions and leads. Use when the user pastes comments, asks to reply to followers, or wants comment triage.
---

# /ig-reply

## Inputs
Comments (pasted or via connector) and `data/account.md` voice.

## Steps
1. Triage each comment: **question**, **praise**, **lead** (buying signal), **critic**, **spam or abuse**.
2. Draft replies: short, warm, specific. Questions get a real answer. Leads get a reply that invites a DM without pitching in public. Critics get calm, factual answers or no reply.
3. Mark spam and abuse for hiding or deleting. Do not reply to it.
4. Show a table: comment, type, suggested reply, action.
5. Suggest 1-2 comments worth pinning, and any repeated question that should become a Reel or story.

## Rules
Approve before send. Never argue publicly. Never promise things the user has not offered.
