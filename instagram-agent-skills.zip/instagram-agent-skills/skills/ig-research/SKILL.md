---
name: ig-research
description: Research a niche: rank competitors' and peers' Reels against each account's own baseline, and find topic gaps. Use when the user wants competitor analysis, niche research or content gap discovery.
---

# /ig-research

## Inputs
Niche, 3-10 accounts to study (or ask the user for them), view counts and dates from the user, links, or connector data.

## Steps
1. For each account, find its **baseline**: typical views per Reel. Rank each Reel against its **own account's** median, not against other accounts. A 50K Reel on a 5K-view account outranks 100K on a 500K account.
2. Extract the top outliers (3x+ baseline) per account.
3. Tag each outlier: topic, hook type, format, length.
4. Find patterns shared across accounts and **gaps**: topics the audience clearly wants that nobody covers well.
5. Output: a ranked outlier table, 3 patterns, 5 gap opportunities, and a recommended next Reel handed to `/ig-reel`.

## Rules
Only use data the user provides or a connector returns. If you cannot access an account, say so, and ask for screenshots or numbers.
