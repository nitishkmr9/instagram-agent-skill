---
name: ig-reel
description: Write a complete Instagram Reel draft: 3 scored hooks, script, on-screen text and beat sheet. Use whenever the user wants a Reel idea turned into a script, asks for hooks, or says things like 'write a reel about X', even if they don't say '/ig-reel'.
---

# /ig-reel

Turn a topic into a shootable Reel draft.

## Inputs
Topic or idea. Read `data/account.md` for niche, audience, voice and goals. If it is missing, run `/ig-profile` setup questions first (2 minutes).

## Steps
1. Pick the Reel goal: reach, trust, or conversion. Default to reach.
2. Read `references/hook-formulas.md`. Choose the 3 formulas that fit the topic best.
3. Write 3 hooks (one per formula). Each hook must be speakable in under 3 seconds and make a viewer stop scrolling.
4. Score each hook 1-10 on: curiosity gap, specificity, relevance to audience, speed to first payoff. Show the total and one line of reasoning. Mark the winner.
5. Write the script for the winning hook, 20-45 seconds (about 55-120 spoken words). One idea only. Structure: Hook, Context (one line), Payoff in 3 beats, Close.
6. Write the on-screen text: one line per beat, max 7 words each.
7. Write the beat sheet as a table: time, spoken line, visual or B-roll, on-screen text.
8. Add a CTA that matches the goal (save, comment keyword, follow) and a 1-line caption seed. Send full captions to `/ig-caption`.

## Output format
```
REEL DRAFT
Hook options (scored): ...
Chosen hook: ...
Script: ...
On-screen text: ...
Beat sheet: (table)
CTA: ...
```

## Rules
Follow `shared/style-rules.md`. Never invent statistics or claim results the user has not had. Do not publish. Offer `/ig-caption` and `/ig-publish` as next steps.
