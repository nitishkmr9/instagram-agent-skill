---
name: ig-analytics
description: Read and explain Instagram analytics: reach, retention, saves, shares, follower growth and best posting times. Use when the user shares insights, asks how a post performed, or wants data-driven decisions.
---

# /ig-analytics

## Inputs
Screenshots, exports or connector data. Ask for the time window (default 30 days).

## Steps
1. Report core metrics: reach, views, watch time or average watch percentage for Reels, saves, shares, comments, profile visits, follows.
2. Compute rates against reach, not followers: save rate, share rate, comment rate.
3. For Reels, judge retention: drop-off point and replays. Suggest hook or pacing fixes by location of drop.
4. Find the best 3 posting windows from the data. Note sample size.
5. Write a 5-line summary: what's working, what's not, one test for next week. Log findings to `data/analytics-log.md` and feed them to `/ig-plan`.

## Rules
Never present guesses as data. Flag samples under 10 posts.
