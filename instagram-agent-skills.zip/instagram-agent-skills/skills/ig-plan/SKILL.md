---
name: ig-plan
description: Build a weekly Instagram content calendar with post types, times, topics and accounts to engage with. Use when the user asks what to post this week, wants a schedule, or needs a content plan.
---

# /ig-plan

## Inputs
`data/account.md`, posting capacity, any recent analytics, upcoming events.

## Steps
1. Default weekly shape (adapt to capacity): 3 Reels, 1 carousel, 2-3 story days, 1 rest day, 1 engagement-only day.
2. Assign each slot: day, format, topic, purpose (reach, teach, trust, convert), time. If analytics exist (`/ig-analytics`), use best-performing times. Otherwise propose evening slots (6-8 PM local) and label them as a starting guess to test.
3. Give every slot a working title and a one-line angle.
4. Build the engagement list: 10 accounts, split into 5 reach accounts (bigger, adjacent), 3 peers (similar size), 2 potential buyers or collaborators. Give a reason for each, and a note on what kind of comment to leave.
5. Save the plan to `data/plan-YYYY-WW.md`.

## Output
A day-by-day table and the engagement list. End by asking which item to produce first.
