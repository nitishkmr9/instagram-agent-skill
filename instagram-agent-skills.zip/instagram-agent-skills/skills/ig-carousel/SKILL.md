---
name: ig-carousel
description: Plan and write a swipeable Instagram carousel: slide-by-slide copy, visual direction and caption. Use when the user wants a carousel, slideshow post, checklist post or educational multi-slide content.
---

# /ig-carousel

## Inputs
Topic, goal (teach, story, sell), slide count (default 7, range 5-10), `data/account.md`.

## Steps
1. Slide 1 is the hook: a promise or tension in under 10 words.
2. Slide 2 sets context or the problem in one line.
3. Middle slides: one idea per slide, max 25 words, a clear mini-headline each.
4. Second-to-last slide: summary or the key takeaway.
5. Final slide: one CTA (save, share, follow).
6. For each slide give: headline, body text, visual direction (layout, icon, image idea).
7. Write the caption by running `/ig-caption` logic.
8. Provide a consistency note: font pairing, 2-3 colors, alignment so the set looks unified.

## Output
Numbered slide table plus caption. Keep text large and sparse, since it is read on a phone.
